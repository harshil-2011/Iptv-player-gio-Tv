#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -f local.properties ] && grep -q '^sdk.dir=' local.properties; then :; else
  echo "Create local.properties with sdk.dir=/path/to/Android/Sdk" >&2
  exit 1
fi
if [ -x ./gradlew ]; then ./gradlew assembleDebug; else gradle assembleDebug; fi
