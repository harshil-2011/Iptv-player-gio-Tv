# IoTB Player (Android TV)

Android TV IPTV player APK project inspired by JioTV Plus UI patterns (hero area, channel rails, TV guide, number tuning) with a focus on smooth playback on Android 7+.

## Features
- Android TV / Leanback launcher support
- Playlist import: M3U/M3U8 URL or local file
- Random channel plays at app start (after playlist is loaded)
- TV guide (EPG): load XMLTV URL/file and show now/next + guide grid
- Number system: press 0–9 to tune channel number, OK to confirm
- Smooth playback: Media3 ExoPlayer with tuned buffers, no-audio-focus-duck options, and hardware decoding defaults
- minSdk 24 (Android 7.0), target/compile 34

## Build
Requires JDK 17 and Android SDK (platform 34, build-tools).  
```bash
cp local.properties.example local.properties
# edit sdk.dir
./gradlew assembleDebug
# or: ./build.sh
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- Some streams require valid User-Agent/Referer or DRM not supported here.
- XMLTV parsing is intentionally lightweight for broad compatibility; very large guides may need paging/DB optimization.
- For best "no lag/no buffer" results on weak Android 7 boxes, use HLS streams with reasonable bitrates and a stable network.
