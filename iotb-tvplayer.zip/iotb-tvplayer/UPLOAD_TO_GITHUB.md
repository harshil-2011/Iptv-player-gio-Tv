# Upload to GitHub (to build APK via Actions)

## Option A — GitHub website (no git push setup)
1. On https://github.com/new create a **new empty repository** (e.g. `iotb-tvplayer`). Do **not** add README/license from the web UI.
2. On the repo page, choose **Add file → Upload files**.
3. Upload **all files/folders inside** this `iotb-tvplayer` folder (including `.github`). Keep the same structure.
4. Commit the upload.
5. Go to **Actions** tab → enable workflows if asked → select **Build APK** → **Run workflow** (if it didn’t run automatically).
6. After it finishes: open the run → **Artifacts** → download **app-debug** → you’ll get `app-debug.apk`.

## Option B — Git command line (if you have GitHub access on this device)
```bash
cd /sdcard/IoTBPlayer/iotb-tvplayer
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
git push -u origin main
```
Then check **Actions** for the APK artifact as above.

## If Actions build fails
- Check the Actions log. Common fixes: Gradle/AGP/JDK/SDK compatibility, dependency download issues, or missing files.
- Share the failing log section and I can help patch the project.

## After installing APK
- Install on Android TV / Android 7+ (enable unknown sources for the installer).
- Import an M3U/M3U8 playlist (URL or local path). Sample: `sample.m3u`.
- App auto-plays a random channel after playlist load.
