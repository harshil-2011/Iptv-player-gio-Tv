package com.iotb.player.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import com.iotb.player.R;
import com.iotb.player.data.AppRepository;
import com.iotb.player.data.Channel;
import com.iotb.player.data.EpgProgram;
import com.iotb.player.utils.ChannelNumberController;

import java.util.List;

public class MainActivity extends FragmentActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ChannelNumberController numberController;
    private TextView numberOverlay;
    private boolean randomStarted = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        numberOverlay = findViewById(R.id.number_overlay);
        findViewById(R.id.btn_import_playlist).setOnClickListener(v -> ImportActivity.open(this, false));
        findViewById(R.id.btn_import_guide).setOnClickListener(v -> ImportActivity.open(this, true));
        findViewById(R.id.btn_guide).setOnClickListener(v -> startActivity(new Intent(this, GuideActivity.class)));
        View hero = findViewById(R.id.hero);
        hero.setOnClickListener(v -> playRandomOrFirst());
        numberController = new ChannelNumberController(new ChannelNumberController.Listener() {
            @Override public void onBuffer(String digits) { numberOverlay.setText(digits); numberOverlay.setVisibility(View.VISIBLE); }
            @Override public void onCommit(int number) {
                Channel c = AppRepository.get().findByNumber(number);
                if (c != null) PlayerActivity.open(MainActivity.this, c);
            }
            @Override public void onClear() { numberOverlay.setVisibility(View.GONE); }
        });
        loadSavedThenRender();
    }

    @Override protected void onResume() {
        super.onResume();
        render();
        if (!randomStarted) {
            randomStarted = true;
            handler.postDelayed(this::autoPlayRandomIfNeeded, 500);
        }
    }

    private void autoPlayRandomIfNeeded() {
        Channel c = AppRepository.get().randomChannel();
        if (c != null && getIntent() != null && !getIntent().getBooleanExtra("no_auto", false)) {
            PlayerActivity.open(this, c);
        }
    }

    private void playRandomOrFirst() {
        List<Channel> ch = AppRepository.get().getChannels();
        if (ch.isEmpty()) { ImportActivity.open(this, false); return; }
        PlayerActivity.open(this, AppRepository.get().randomChannel());
    }

    private void loadSavedThenRender() {
        AppRepository repo = AppRepository.get();
        String p = repo.prefs().getString("playlist_source", null);
        if (p != null && repo.getChannels().isEmpty()) {
            repo.importPlaylist(p, new AppRepository.Callback<List<Channel>>() {
                @Override public void onSuccess(List<Channel> value) { runOnUiThread(() -> { render(); autoPlayRandomIfNeeded(); }); }
                @Override public void onError(Exception e) { runOnUiThread(MainActivity.this::render); }
            });
        }
        String g = repo.prefs().getString("guide_source", null);
        if (g != null) repo.importGuide(g, new AppRepository.Callback<Integer>() {
            @Override public void onSuccess(Integer value) { runOnUiThread(MainActivity.this::render); }
            @Override public void onError(Exception e) {}
        });
        render();
    }

    private void render() {
        LinearLayout row = findViewById(R.id.channel_row);
        row.removeAllViews();
        List<Channel> channels = AppRepository.get().getChannels();
        TextView heroChannel = findViewById(R.id.hero_channel);
        TextView heroEpg = findViewById(R.id.hero_epg);
        if (channels.isEmpty()) {
            heroChannel.setText(R.string.no_playlist);
            heroEpg.setText("");
            return;
        }
        Channel first = channels.get(0);
        heroChannel.setText(first.displayName());
        heroEpg.setText(epgLine(first));
        LayoutInflater inf = LayoutInflater.from(this);
        int limit = Math.min(channels.size(), 40);
        for (int i = 0; i < limit; i++) {
            Channel c = channels.get(i);
            View v = inf.inflate(R.layout.item_channel, row, false);
            ((TextView) v.findViewById(R.id.ch_num)).setText(String.valueOf(c.number));
            ((TextView) v.findViewById(R.id.ch_name)).setText(c.name);
            ((TextView) v.findViewById(R.id.ch_group)).setText(c.group);
            v.setOnClickListener(x -> PlayerActivity.open(this, c));
            v.setOnFocusChangeListener((view, hasFocus) -> view.animate().scaleX(hasFocus ? 1.06f : 1f).scaleY(hasFocus ? 1.06f : 1f).setDuration(120).start());
            row.addView(v);
        }
    }

    private String epgLine(Channel c) {
        EpgProgram now = AppRepository.get().nowFor(c);
        EpgProgram next = AppRepository.get().nextFor(c);
        if (now == null && next == null) return c.group;
        StringBuilder sb = new StringBuilder();
        if (now != null) sb.append("Now: ").append(now.title);
        if (next != null) { if (sb.length() > 0) sb.append("  •  "); sb.append("Next: ").append(next.title); }
        return sb.toString();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (numberController != null && numberController.onKeyDown(keyCode)) return true;
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_GUIDE || keyCode == KeyEvent.KEYCODE_INFO) {
            startActivity(new Intent(this, GuideActivity.class));
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
