package com.iotb.player.player;

import android.content.Context;

import androidx.annotation.OptIn;
import androidx.media3.common.C;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;

public final class PlayerFactory {
    private PlayerFactory() {}

    @OptIn(markerClass = UnstableApi.class)
    public static ExoPlayer create(Context context, String userAgent, String referer) {
        // Favor smooth startup and fewer stalls on Android 7 / low-RAM TV boxes.
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                        15000,  // min buffer
                        50000,  // max buffer
                        1200,   // playback start
                        2500    // rebuffer
                )
                .setPrioritizeTimeOverSizeThresholds(true)
                .setBackBuffer(5000, true)
                .build();

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(context);
        trackSelector.setParameters(trackSelector.buildUponParameters()
                .setMaxVideoBitrate(8_000_000) // cap for weak devices/networks; adjust as needed
                .setPreferredAudioLanguage("en")
                .setAllowAudioMixedMimeTypeAdaptiveness(true)
                .setAllowVideoMixedMimeTypeAdaptiveness(true));

        DefaultRenderersFactory renderersFactory = new DefaultRenderersFactory(context)
                .setEnableDecoderFallback(true)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER);

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(12000)
                .setReadTimeoutMs(20000)
                .setUserAgent(userAgent == null || userAgent.isEmpty() ? "IoTBPlayer/1.0 (AndroidTV)" : userAgent)
                .setKeepPostFor302Redirects(true);
        if (referer != null && !referer.isEmpty()) {
            java.util.HashMap<String, String> headers = new java.util.HashMap<>();
            headers.put("Referer", referer);
            http.setDefaultRequestProperties(headers);
        }
        DefaultDataSource.Factory dataSource = new DefaultDataSource.Factory(context, http);

        ExoPlayer player = new ExoPlayer.Builder(context, renderersFactory)
                .setLoadControl(loadControl)
                .setTrackSelector(trackSelector)
                .setMediaSourceFactory(new androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSource))
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build();
        player.setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
        player.setPlayWhenReady(true);
        return player;
    }
}
