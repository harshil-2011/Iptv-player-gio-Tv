package com.iotb.player.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import com.iotb.player.R;
import com.iotb.player.data.AppRepository;
import com.iotb.player.data.Channel;

import java.util.List;

public class ImportActivity extends FragmentActivity {
    private static final String EXTRA_GUIDE = "guide";

    public static void open(Activity a, boolean guide) {
        Intent i = new Intent(a, ImportActivity.class);
        i.putExtra(EXTRA_GUIDE, guide);
        a.startActivity(i);
    }

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import);
        boolean guide = getIntent().getBooleanExtra(EXTRA_GUIDE, false);
        ((TextView) findViewById(R.id.import_title)).setText(guide ? R.string.import_guide : R.string.import_playlist);
        EditText input = (EditText) findViewById(R.id.import_url);
        input.setHint(getString(guide ? R.string.guide_url_hint : R.string.playlist_url_hint));
        String last = AppRepository.get().prefs().getString(guide ? "guide_source" : "playlist_source", "");
        if (last == null || last.isEmpty()) last = guide ? "sample_guide.xml" : "sample.m3u";
        input.setText(last);
        findViewById(R.id.import_cancel).setOnClickListener(v -> finish());
        findViewById(R.id.import_load).setOnClickListener(v -> {
            String src = input.getText().toString().trim();
            if (src.isEmpty()) return;
            Toast.makeText(ImportActivity.this, R.string.loading, Toast.LENGTH_SHORT).show();
            if (guide) {
                AppRepository.get().importGuide(src, new AppRepository.Callback<Integer>() {
                    @Override public void onSuccess(Integer value) { runOnUiThread(() -> { Toast.makeText(ImportActivity.this, "Guide loaded: " + value + " channels", Toast.LENGTH_SHORT).show(); finish(); }); }
                    @Override public void onError(Exception e) { runOnUiThread(() -> Toast.makeText(ImportActivity.this, "Guide error: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
                });
            } else {
                AppRepository.get().importPlaylist(src, new AppRepository.Callback<List<Channel>>() {
                    @Override public void onSuccess(List<Channel> value) { runOnUiThread(() -> { Toast.makeText(ImportActivity.this, "Playlist loaded: " + value.size() + " channels", Toast.LENGTH_SHORT).show(); finish(); }); }
                    @Override public void onError(Exception e) { runOnUiThread(() -> Toast.makeText(ImportActivity.this, "Playlist error: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
                });
            }
        });
    }
}
