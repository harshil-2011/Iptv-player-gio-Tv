package com.iotb.player.data;

public class EpgProgram {
    public String channelId;
    public String title;
    public String description;
    public long startMs;
    public long endMs;

    public EpgProgram(String channelId, String title, String description, long startMs, long endMs) {
        this.channelId = channelId;
        this.title = title == null ? "" : title;
        this.description = description == null ? "" : description;
        this.startMs = startMs;
        this.endMs = endMs;
    }

    public boolean isLive(long now) {
        return startMs <= now && now < endMs;
    }
}
