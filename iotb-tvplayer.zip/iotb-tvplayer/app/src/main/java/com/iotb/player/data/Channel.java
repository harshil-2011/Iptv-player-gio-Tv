package com.iotb.player.data;

import java.io.Serializable;

public class Channel implements Serializable {
    public int number;
    public String name;
    public String group;
    public String logo;
    public String url;
    public String tvgId;
    public String userAgent;
    public String referer;

    public Channel(int number, String name, String group, String logo, String url, String tvgId) {
        this.number = number;
        this.name = name == null ? "Channel " + number : name.trim();
        this.group = group == null || group.trim().isEmpty() ? "All Channels" : group.trim();
        this.logo = logo;
        this.url = url == null ? "" : url.trim();
        this.tvgId = tvgId;
    }

    public String displayName() {
        return number > 0 ? number + "  " + name : name;
    }
}
