package com.iotb.player.ui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.fragment.app.FragmentActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import com.iotb.player.R;
import com.iotb.player.data.AppRepository;
import com.iotb.player.data.Channel;
import com.iotb.player.data.EpgProgram;
import com.iotb.player.player.PlayerFactory;
import com.iotb.player.utils.ChannelNumberController;

public class PlayerActivity extends FragmentActivity {
    private static final String EXTRA_INDEX = "index";
    private ExoPlayer player;
    private PlayerView playerView;
    private Channel current;
    private int index;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private View overlay;
    private TextView numberView;
    private ChannelNumberController numberController;
    private final Runnable hideOverlay = () -> overlay.setVisibility(View.GONE);

    public static void open(Activity a, Channel c) {
        int idx = AppRepository.get().indexOf(c);
        Intent i = new Intent(a, PlayerActivity.class);
        i.putExtra(EXTRA_INDEX, idx);
        a.startActivity(i);
    }

    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        playerView = findViewById(R.id.player_view);
        overlay = findViewById(R.id.player_overlay);
        numberView = findViewById(R.id.player_number);
        index = getIntent().getIntExtra(EXTRA_INDEX, -1);
        if (index < 0) { current = AppRepository.get().randomChannel(); index = AppRepository.get().indexOf(current); }
        else current = AppRepository.get().byIndex(index);
        numberController = new ChannelNumberController(new ChannelNumberController.Listener() {
            @Override public void onBuffer(String digits) { numberView.setText(digits); numberView.setVisibility(View.VISIBLE); }
            @Override public void onCommit(int number) {
                Channel c = AppRepository.get().findByNumber(number);
                if (c != null) tuneTo(AppRepository.get().indexOf(c)); else Toast.makeText(PlayerActivity.this, "Channel not found", Toast.LENGTH_SHORT).show();
            }
            @Override public void onClear() { numberView.setVisibility(View.GONE); }
        });
    }

    @Override protected void onStart() {
        super.onStart();
        initPlayer();
    }

    @Override protected void onResume() {
        super.onResume();
        if (player != null) player.setPlayWhenReady(true);
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override protected void onStop() {
        super.onStop();
        releasePlayer();
    }

    @OptIn(markerClass = UnstableApi.class)
    private void initPlayer() {
        if (current == null) { Toast.makeText(this, R.string.no_playlist, Toast.LENGTH_LONG).show(); finish(); return; }
        player = PlayerFactory.create(this, current.userAgent, current.referer);
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_READY) showOverlay();
                if (playbackState == Player.STATE_ENDED) nextChannel();
            }
            @Override public void onPlayerError(androidx.media3.common.PlaybackException error) {
                Toast.makeText(PlayerActivity.this, "Stream error, trying next…", Toast.LENGTH_SHORT).show();
                handler.postDelayed(() -> nextChannel(), 1200);
            }
        });
        playCurrent();
    }

    private void playCurrent() {
        if (player == null || current == null || current.url == null || current.url.isEmpty()) return;
        MediaItem.Builder b = new MediaItem.Builder().setUri(Uri.parse(current.url)).setLiveConfiguration(new MediaItem.LiveConfiguration.Builder().setMaxPlaybackSpeed(1.02f).build());
        String u = current.url.toLowerCase();
        if (u.contains(".m3u8")) b.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (u.contains(".mpd")) b.setMimeType(MimeTypes.APPLICATION_MPD);
        player.setMediaItem(b.build());
        player.prepare();
        player.play();
        showOverlay();
    }

    private void tuneTo(int newIndex) {
        Channel c = AppRepository.get().byIndex(newIndex);
        if (c == null) return;
        index = newIndex; current = c;
        releasePlayer();
        initPlayer();
    }

    private void nextChannel() { tuneTo((index + 1) % Math.max(1, AppRepository.get().getChannels().size())); }
    private void prevChannel() {
        int size = Math.max(1, AppRepository.get().getChannels().size());
        tuneTo((index - 1 + size) % size);
    }

    private void showOverlay() {
        ((TextView) findViewById(R.id.player_channel)).setText(current == null ? "" : current.displayName());
        EpgProgram now = AppRepository.get().nowFor(current);
        EpgProgram next = AppRepository.get().nextFor(current);
        String epg = (now == null ? "" : "Now: " + now.title) + (next == null ? "" : (now == null ? "" : "  •  ") + "Next: " + next.title);
        ((TextView) findViewById(R.id.player_epg)).setText(epg);
        overlay.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideOverlay);
        handler.postDelayed(hideOverlay, 4500);
    }

    private void releasePlayer() {
        handler.removeCallbacks(hideOverlay);
        if (player != null) { playerView.setPlayer(null); player.release(); player = null; }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && numberController != null && numberController.onKeyDown(event.getKeyCode())) return true;
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (event.getKeyCode()) {
                case KeyEvent.KEYCODE_CHANNEL_UP: case KeyEvent.KEYCODE_DPAD_UP: nextChannel(); return true;
                case KeyEvent.KEYCODE_CHANNEL_DOWN: case KeyEvent.KEYCODE_DPAD_DOWN: prevChannel(); return true;
                case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_INFO: showOverlay(); return true;
                case KeyEvent.KEYCODE_GUIDE: case KeyEvent.KEYCODE_MENU: startActivity(new Intent(this, GuideActivity.class)); return true;
                case KeyEvent.KEYCODE_BACK:
                    if (overlay.getVisibility() == View.VISIBLE) { overlay.setVisibility(View.GONE); return true; }
                    Intent home = new Intent(this, MainActivity.class); home.putExtra("no_auto", true); startActivity(home); finish(); return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }
}
