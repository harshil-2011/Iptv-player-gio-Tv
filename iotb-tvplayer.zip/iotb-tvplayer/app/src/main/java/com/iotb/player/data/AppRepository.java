package com.iotb.player.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.text.TextUtils;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AppRepository {
    private static AppRepository instance;
    private final Context app;
    private final SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Channel> channels = new ArrayList<>();
    private final Map<String, List<EpgProgram>> epgByChannel = new HashMap<>();
    private final Random random = new Random();

    private AppRepository(Context context) {
        this.app = context.getApplicationContext();
        this.prefs = app.getSharedPreferences("iotb", Context.MODE_PRIVATE);
    }

    public static synchronized void init(Context context) {
        if (instance == null) instance = new AppRepository(context);
    }

    public static AppRepository get() { return instance; }

    public SharedPreferences prefs() { return prefs; }

    public synchronized List<Channel> getChannels() { return new ArrayList<>(channels); }

    public synchronized Map<String, List<Channel>> getGroupedChannels() {
        Map<String, List<Channel>> grouped = new LinkedHashMap<>();
        for (Channel c : channels) {
            grouped.computeIfAbsent(c.group, k -> new ArrayList<>()).add(c);
        }
        return grouped;
    }

    public synchronized Channel findByNumber(int number) {
        for (Channel c : channels) if (c.number == number) return c;
        return null;
    }

    public synchronized Channel randomChannel() {
        if (channels.isEmpty()) return null;
        return channels.get(random.nextInt(channels.size()));
    }

    public synchronized int indexOf(Channel channel) {
        for (int i = 0; i < channels.size(); i++) {
            if (channels.get(i).url.equals(channel.url) && channels.get(i).number == channel.number) return i;
        }
        return -1;
    }

    public synchronized Channel byIndex(int idx) {
        if (idx < 0 || idx >= channels.size()) return null;
        return channels.get(idx);
    }

    public interface Callback<T> { void onSuccess(T value); void onError(Exception e); }

    public void importPlaylist(String source, Callback<List<Channel>> cb) {
        io.execute(() -> {
            try {
                List<String> lines = readLines(source);
                List<Channel> parsed = parseM3U(lines);
                synchronized (this) {
                    channels.clear();
                    channels.addAll(parsed);
                }
                prefs.edit().putString("playlist_source", source).apply();
                cb.onSuccess(parsed);
            } catch (Exception e) {
                cb.onError(e);
            }
        });
    }

    public void importGuide(String source, Callback<Integer> cb) {
        io.execute(() -> {
            try (InputStream in = open(source)) {
                Map<String, List<EpgProgram>> parsed = parseXmlTv(in);
                synchronized (this) {
                    epgByChannel.clear();
                    epgByChannel.putAll(parsed);
                }
                prefs.edit().putString("guide_source", source).apply();
                cb.onSuccess(parsed.size());
            } catch (Exception e) {
                cb.onError(e);
            }
        });
    }

    public synchronized EpgProgram nowFor(Channel c) {
        return findProgram(c, System.currentTimeMillis(), true);
    }

    public synchronized EpgProgram nextFor(Channel c) {
        EpgProgram now = nowFor(c);
        if (now == null) return findProgram(c, System.currentTimeMillis(), false);
        return findProgram(c, now.endMs + 1000, false);
    }

    public synchronized List<EpgProgram> programsFor(Channel c) {
        String key = epgKey(c);
        if (key == null) return Collections.emptyList();
        List<EpgProgram> list = epgByChannel.get(key);
        return list == null ? Collections.emptyList() : new ArrayList<>(list);
    }

    private String epgKey(Channel c) {
        if (c == null) return null;
        if (!TextUtils.isEmpty(c.tvgId) && epgByChannel.containsKey(c.tvgId)) return c.tvgId;
        if (epgByChannel.containsKey(c.name)) return c.name;
        return c.tvgId != null ? c.tvgId : c.name;
    }

    private EpgProgram findProgram(Channel c, long when, boolean liveOnly) {
        String key = epgKey(c);
        if (key == null) return null;
        List<EpgProgram> list = epgByChannel.get(key);
        if (list == null) return null;
        EpgProgram firstUpcoming = null;
        for (EpgProgram p : list) {
            if (p.isLive(when)) return p;
            if (!liveOnly && p.startMs >= when && firstUpcoming == null) firstUpcoming = p;
        }
        return firstUpcoming;
    }

    private List<String> readLines(String source) throws Exception {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(open(source), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) lines.add(line);
        }
        return lines;
    }

    private InputStream open(String source) throws Exception {
        if (source.startsWith("content://")) return app.getContentResolver().openInputStream(Uri.parse(source));
        if (source.startsWith("http://") || source.startsWith("https://")) {
            HttpURLConnection conn = (HttpURLConnection) new URL(source).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setRequestProperty("User-Agent", "IoTBPlayer/1.0");
            conn.setInstanceFollowRedirects(true);
            return conn.getInputStream();
        }
        File f = new File(source);
        if (f.exists()) return new FileInputStream(f);
        return app.getAssets().open(source);
    }

    static List<Channel> parseM3U(List<String> lines) {
        List<Channel> out = new ArrayList<>();
        String name = null, logo = null, group = null, tvgId = null, ua = null, ref = null;
        int number = 0;
        for (String raw : lines) {
            String line = raw == null ? "" : raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                name = extractName(line);
                logo = attr(line, "tvg-logo");
                group = attr(line, "group-title");
                tvgId = attr(line, "tvg-id");
                String chNum = attr(line, "tvg-chno");
                if (chNum == null) chNum = attr(line, "channel-number");
                try { number = chNum == null ? 0 : Integer.parseInt(chNum.replaceAll("[^0-9]", "")); } catch (Exception ignored) { number = 0; }
            } else if (line.startsWith("#EXTVLCOPT:http-user-agent=")) {
                ua = line.substring(line.indexOf('=') + 1).trim();
            } else if (line.startsWith("#EXTVLCOPT:http-referrer=") || line.startsWith("#EXTVLCOPT:http-referer=")) {
                ref = line.substring(line.indexOf('=') + 1).trim();
            } else if (!line.startsWith("#")) {
                if (name == null || name.isEmpty()) name = "Channel " + (out.size() + 1);
                if (number <= 0) number = out.size() + 1;
                Channel c = new Channel(number, name, group, logo, line, tvgId);
                c.userAgent = ua; c.referer = ref;
                out.add(c);
                name = logo = group = tvgId = ua = ref = null; number = 0;
            }
        }
        return out;
    }

    private static String extractName(String extinf) {
        int comma = extinf.lastIndexOf(',');
        if (comma >= 0 && comma + 1 < extinf.length()) return extinf.substring(comma + 1).trim();
        return "Channel";
    }

    private static String attr(String line, String key) {
        String[] needles = { key + "=\"", key + "='" };
        for (String needle : needles) {
            int i = line.indexOf(needle);
            if (i < 0) continue;
            int s = i + needle.length();
            char q = needle.charAt(needle.length() - 1);
            int e = line.indexOf(q, s);
            if (e > s) return line.substring(s, e);
        }
        return null;
    }

    static Map<String, List<EpgProgram>> parseXmlTv(InputStream in) throws Exception {
        Map<String, List<EpgProgram>> map = new HashMap<>();
        XmlPullParserFactory f = XmlPullParserFactory.newInstance();
        f.setNamespaceAware(false);
        XmlPullParser p = f.newPullParser();
        p.setInput(in, "UTF-8");
        String channel = null, start = null, stop = null, title = null, desc = null;
        boolean inTitle = false, inDesc = false;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            String tag = p.getName();
            if (ev == XmlPullParser.START_TAG) {
                if ("programme".equals(tag)) { channel = p.getAttributeValue(null, "channel"); start = p.getAttributeValue(null, "start"); stop = p.getAttributeValue(null, "stop"); title = desc = null; }
                else if ("title".equals(tag)) inTitle = true;
                else if ("desc".equals(tag)) inDesc = true;
            } else if (ev == XmlPullParser.TEXT) {
                if (inTitle) title = append(title, p.getText());
                if (inDesc) desc = append(desc, p.getText());
            } else if (ev == XmlPullParser.END_TAG) {
                if ("title".equals(tag)) inTitle = false;
                else if ("desc".equals(tag)) inDesc = false;
                else if ("programme".equals(tag) && channel != null) {
                    long s = parseXmlTvTime(start), e = parseXmlTvTime(stop);
                    if (e <= s) e = s + 30L * 60_000L;
                    map.computeIfAbsent(channel, k -> new ArrayList<>()).add(new EpgProgram(channel, title, desc, s, e));
                }
            }
            ev = p.next();
        }
        for (List<EpgProgram> list : map.values()) Collections.sort(list, (a, b) -> Long.compare(a.startMs, b.startMs));
        return map;
    }

    private static String append(String base, String text) {
        if (text == null) return base;
        String t = text.trim();
        if (t.isEmpty()) return base;
        return base == null ? t : base + t;
    }

    static long parseXmlTvTime(String v) {
        if (v == null || v.trim().isEmpty()) return 0;
        String t = v.trim();
        try {
            // 20240101123000 +0000 or 20240101123000
            String base = t.length() >= 14 ? t.substring(0, 14) : t;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            if (t.length() > 14) {
                String tz = t.substring(14).trim().replace(":", "");
                if (tz.matches("[+-]\\d{4}")) {
                    sdf.setTimeZone(TimeZone.getTimeZone("GMT" + tz.substring(0, 3) + ":" + tz.substring(3)));
                }
            }
            Date d = sdf.parse(base);
            return d == null ? 0 : d.getTime();
        } catch (Exception e) {
            return 0;
        }
    }
}
