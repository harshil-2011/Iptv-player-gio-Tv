package com.iotb.player.utils;

import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;

public class ChannelNumberController {
    public interface Listener { void onBuffer(String digits); void onCommit(int number); void onClear(); }
    private final Listener listener;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final StringBuilder buf = new StringBuilder();
    private final Runnable commit = () -> {
        if (buf.length() == 0) return;
        try { listener.onCommit(Integer.parseInt(buf.toString())); } catch (Exception ignored) {}
        buf.setLength(0);
        listener.onClear();
    };

    public ChannelNumberController(Listener listener) { this.listener = listener; }

    public boolean onKeyDown(int keyCode) {
        int digit = -1;
        if (keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9) digit = keyCode - KeyEvent.KEYCODE_0;
        if (keyCode >= KeyEvent.KEYCODE_NUMPAD_0 && keyCode <= KeyEvent.KEYCODE_NUMPAD_9) digit = keyCode - KeyEvent.KEYCODE_NUMPAD_0;
        if (digit >= 0) {
            if (buf.length() >= 4) buf.setLength(0);
            buf.append(digit);
            listener.onBuffer(buf.toString());
            h.removeCallbacks(commit);
            h.postDelayed(commit, 1800);
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            if (buf.length() > 0) { h.removeCallbacks(commit); commit.run(); return true; }
        }
        if (keyCode == KeyEvent.KEYCODE_BACK && buf.length() > 0) {
            h.removeCallbacks(commit); buf.setLength(0); listener.onClear(); return true;
        }
        return false;
    }
}
