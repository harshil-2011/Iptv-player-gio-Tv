package com.iotb.player.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import com.iotb.player.R;
import com.iotb.player.data.AppRepository;
import com.iotb.player.data.Channel;
import com.iotb.player.data.EpgProgram;

import java.util.List;

public class GuideActivity extends FragmentActivity {
    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        LinearLayout list = findViewById(R.id.guide_list);
        LayoutInflater inf = LayoutInflater.from(this);
        List<Channel> channels = AppRepository.get().getChannels();
        int limit = Math.min(channels.size(), 120);
        for (int i = 0; i < limit; i++) {
            Channel c = channels.get(i);
            View v = inf.inflate(R.layout.item_guide_row, list, false);
            ((TextView) v.findViewById(R.id.guide_channel)).setText(c.displayName());
            EpgProgram now = AppRepository.get().nowFor(c);
            EpgProgram next = AppRepository.get().nextFor(c);
            ((TextView) v.findViewById(R.id.guide_now)).setText(now == null ? "No guide data" : "Now: " + now.title);
            ((TextView) v.findViewById(R.id.guide_next)).setText(next == null ? "" : "Next: " + next.title);
            v.setOnClickListener(x -> PlayerActivity.open(this, c));
            v.setOnFocusChangeListener((view, hasFocus) -> view.animate().scaleX(hasFocus ? 1.02f : 1f).scaleY(hasFocus ? 1.02f : 1f).setDuration(100).start());
            list.addView(v);
        }
    }
}
