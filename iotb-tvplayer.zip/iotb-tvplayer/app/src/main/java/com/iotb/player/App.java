package com.iotb.player;

import android.app.Application;
import com.iotb.player.data.AppRepository;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AppRepository.init(this);
    }
}
